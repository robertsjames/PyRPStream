__version__ = '0.1.0'
__author__ = 'Robert James, Fiona Alder'
__author_email__ = 'robert.james.19@ucl.ac.uk'
